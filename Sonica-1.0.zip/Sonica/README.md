# Sonica 1.0

Primera versión funcional de Sonica: aplicación web musical con Node.js + Express + MySQL.

## Requisitos
- Node.js 18+
- MySQL 8+

## Instalación

1. Copia `.env.example` a `.env`.
2. Configura tu usuario y contraseña de MySQL.
3. Ejecuta:

```bash
npm install
npm start
```

Al iniciar, Sonica intenta crear automáticamente la base de datos `sonica` y sus tablas.

Abre:

http://localhost:3000

## API inicial

- `GET /api/health`
- `GET /api/canciones`
- `POST /api/canciones`
- `GET /api/artistas`
- `POST /api/artistas`
- `GET /api/albumes`
- `POST /api/albumes`
- `GET /api/playlists`
- `POST /api/playlists`
- `POST /api/playlists/:id/canciones`
- `POST /api/usuarios`
- `GET /api/usuarios`

## Modelo

usuarios -> playlists -> playlist_canciones -> canciones -> artistas/albumes

Esta versión usa URLs de audio públicas/propias como referencia. No incluye contenido musical con copyright.
