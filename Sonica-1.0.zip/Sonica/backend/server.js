const express = require("express");
const cors = require("cors");
const path = require("path");
const { initializeDatabase, db } = require("./config/database");

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "../frontend")));

app.get("/api/health", async (req, res) => {
  try {
    await db().query("SELECT 1");
    res.json({ ok: true, app: "Sonica", database: "MySQL conectado" });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.get("/api/canciones", async (req, res) => {
  try {
    const [rows] = await db().query(`
      SELECT c.*, a.nombre AS artista, al.titulo AS album
      FROM canciones c
      LEFT JOIN artistas a ON a.id = c.artista_id
      LEFT JOIN albumes al ON al.id = c.album_id
      ORDER BY c.id DESC
    `);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post("/api/canciones", async (req, res) => {
  try {
    const { titulo, artista_id = null, album_id = null, genero = "", duracion_segundos = 0, audio_url = "", portada_url = "" } = req.body;
    if (!titulo) return res.status(400).json({ error: "El título es obligatorio." });
    const [r] = await db().execute(
      `INSERT INTO canciones (titulo, artista_id, album_id, genero, duracion_segundos, audio_url, portada_url)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [titulo, artista_id, album_id, genero, duracion_segundos, audio_url, portada_url]
    );
    res.status(201).json({ id: r.insertId, mensaje: "Canción creada." });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get("/api/artistas", async (req, res) => {
  try {
    const [rows] = await db().query("SELECT * FROM artistas ORDER BY nombre");
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post("/api/artistas", async (req, res) => {
  try {
    const { nombre, imagen_url = "" } = req.body;
    if (!nombre) return res.status(400).json({ error: "El nombre es obligatorio." });
    const [r] = await db().execute("INSERT INTO artistas (nombre, imagen_url) VALUES (?, ?)", [nombre, imagen_url]);
    res.status(201).json({ id: r.insertId, mensaje: "Artista creado." });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get("/api/albumes", async (req, res) => {
  try {
    const [rows] = await db().query(`
      SELECT al.*, a.nombre AS artista
      FROM albumes al LEFT JOIN artistas a ON a.id = al.artista_id
      ORDER BY al.id DESC
    `);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post("/api/albumes", async (req, res) => {
  try {
    const { titulo, artista_id = null, portada_url = "", anio = null } = req.body;
    if (!titulo) return res.status(400).json({ error: "El título es obligatorio." });
    const [r] = await db().execute(
      "INSERT INTO albumes (titulo, artista_id, portada_url, anio) VALUES (?, ?, ?, ?)",
      [titulo, artista_id, portada_url, anio]
    );
    res.status(201).json({ id: r.insertId, mensaje: "Álbum creado." });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get("/api/usuarios", async (req, res) => {
  try {
    const [rows] = await db().query("SELECT id, nombre, email, creado_en FROM usuarios ORDER BY id DESC");
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post("/api/usuarios", async (req, res) => {
  try {
    const { nombre, email, password_hash = "" } = req.body;
    if (!nombre || !email) return res.status(400).json({ error: "Nombre y email son obligatorios." });
    const [r] = await db().execute(
      "INSERT INTO usuarios (nombre, email, password_hash) VALUES (?, ?, ?)",
      [nombre, email, password_hash]
    );
    res.status(201).json({ id: r.insertId, mensaje: "Usuario creado." });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get("/api/playlists", async (req, res) => {
  try {
    const [rows] = await db().query(`
      SELECT p.id, p.nombre, p.descripcion, p.usuario_id,
             COUNT(pc.cancion_id) AS total_canciones
      FROM playlists p
      LEFT JOIN playlist_canciones pc ON pc.playlist_id = p.id
      GROUP BY p.id
      ORDER BY p.id DESC
    `);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post("/api/playlists", async (req, res) => {
  try {
    const { nombre, descripcion = "", usuario_id = null } = req.body;
    if (!nombre) return res.status(400).json({ error: "El nombre es obligatorio." });
    const [r] = await db().execute(
      "INSERT INTO playlists (nombre, descripcion, usuario_id) VALUES (?, ?, ?)",
      [nombre, descripcion, usuario_id]
    );
    res.status(201).json({ id: r.insertId, mensaje: "Playlist creada." });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post("/api/playlists/:id/canciones", async (req, res) => {
  try {
    const playlistId = Number(req.params.id);
    const { cancion_id, posicion = 0 } = req.body;
    await db().execute(
      "INSERT INTO playlist_canciones (playlist_id, cancion_id, posicion) VALUES (?, ?, ?)",
      [playlistId, cancion_id, posicion]
    );
    res.status(201).json({ mensaje: "Canción agregada a la playlist." });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post("/api/reproducciones", async (req, res) => {
  try {
    const { cancion_id, usuario_id = null } = req.body;
    await db().execute(
      "INSERT INTO reproducciones (cancion_id, usuario_id) VALUES (?, ?)",
      [cancion_id, usuario_id]
    );
    res.status(201).json({ mensaje: "Reproducción registrada." });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

initializeDatabase()
  .then(() => app.listen(PORT, () => console.log(`Sonica ejecutándose en http://localhost:${PORT}`)))
  .catch(err => {
    console.error("No se pudo iniciar Sonica:", err.message);
    process.exit(1);
  });
