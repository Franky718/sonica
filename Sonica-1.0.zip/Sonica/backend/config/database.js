const mysql = require("mysql2/promise");
require("dotenv").config();

const config = {
  host: process.env.DB_HOST || "localhost",
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "sonica"
};

let pool;

async function initializeDatabase() {
  const serverConnection = await mysql.createConnection({
    host: config.host,
    port: config.port,
    user: config.user,
    password: config.password
  });

  await serverConnection.query(
    `CREATE DATABASE IF NOT EXISTS \`${config.database}\`
     CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
  );
  await serverConnection.end();

  pool = mysql.createPool({
    ...config,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  });

  const fs = require("fs");
  const path = require("path");
  const schema = fs.readFileSync(
    path.join(__dirname, "../../database/schema.sql"),
    "utf8"
  );

  // Ejecuta cada sentencia del esquema por separado.
  for (const statement of schema
    .split(";")
    .map(s => s.trim())
    .filter(Boolean)) {
    await pool.query(statement);
  }

  console.log(`MySQL conectado. Base de datos: ${config.database}`);
  return pool;
}

function db() {
  if (!pool) throw new Error("La base de datos todavía no ha sido inicializada.");
  return pool;
}

module.exports = { initializeDatabase, db };
