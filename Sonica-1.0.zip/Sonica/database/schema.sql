CREATE DATABASE IF NOT EXISTS sonica
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE sonica;

CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS artistas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(150) NOT NULL,
  imagen_url TEXT,
  creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS albumes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  artista_id INT NULL,
  titulo VARCHAR(200) NOT NULL,
  portada_url TEXT,
  anio SMALLINT NULL,
  creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_album_artista FOREIGN KEY (artista_id)
    REFERENCES artistas(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS canciones (
  id INT AUTO_INCREMENT PRIMARY KEY,
  artista_id INT NULL,
  album_id INT NULL,
  titulo VARCHAR(200) NOT NULL,
  genero VARCHAR(80),
  duracion_segundos INT DEFAULT 0,
  audio_url TEXT,
  portada_url TEXT,
  creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_cancion_artista FOREIGN KEY (artista_id)
    REFERENCES artistas(id) ON DELETE SET NULL,
  CONSTRAINT fk_cancion_album FOREIGN KEY (album_id)
    REFERENCES albumes(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS playlists (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NULL,
  nombre VARCHAR(150) NOT NULL,
  descripcion TEXT,
  creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_playlist_usuario FOREIGN KEY (usuario_id)
    REFERENCES usuarios(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS playlist_canciones (
  playlist_id INT NOT NULL,
  cancion_id INT NOT NULL,
  posicion INT DEFAULT 0,
  agregado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (playlist_id, cancion_id),
  CONSTRAINT fk_pc_playlist FOREIGN KEY (playlist_id)
    REFERENCES playlists(id) ON DELETE CASCADE,
  CONSTRAINT fk_pc_cancion FOREIGN KEY (cancion_id)
    REFERENCES canciones(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS reproducciones (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NULL,
  cancion_id INT NOT NULL,
  reproducida_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_rep_usuario FOREIGN KEY (usuario_id)
    REFERENCES usuarios(id) ON DELETE SET NULL,
  CONSTRAINT fk_rep_cancion FOREIGN KEY (cancion_id)
    REFERENCES canciones(id) ON DELETE CASCADE
);
