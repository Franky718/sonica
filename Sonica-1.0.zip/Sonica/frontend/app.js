async function api(url, options = {}) {
  const r = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...options
  });
  const data = await r.json();
  if (!r.ok) throw new Error(data.error || "Error");
  return data;
}

async function checkHealth() {
  try {
    const data = await api("/api/health");
    document.querySelector("#status").textContent = "● MySQL conectado";
  } catch {
    document.querySelector("#status").textContent = "● Error de conexión";
  }
}

async function cargarCanciones() {
  const data = await api("/api/canciones");
  const box = document.querySelector("#songs");
  box.innerHTML = data.length
    ? data.map(x => `<div class="item"><b>${escapeHtml(x.titulo)}</b><br><span class="muted">${escapeHtml(x.artista || "Artista desconocido")} · ${escapeHtml(x.genero || "Sin género")}</span></div>`).join("")
    : '<div class="muted">No hay canciones todavía.</div>';
}

async function cargarArtistas() {
  const data = await api("/api/artistas");
  document.querySelector("#artists").innerHTML = data.length
    ? data.map(x => `<div class="item">${escapeHtml(x.nombre)}</div>`).join("")
    : '<div class="muted">No hay artistas todavía.</div>';
}

async function cargarPlaylists() {
  const data = await api("/api/playlists");
  document.querySelector("#playlists").innerHTML = data.length
    ? data.map(x => `<div class="item"><b>${escapeHtml(x.nombre)}</b><br><span class="muted">${x.total_canciones} canción(es)</span></div>`).join("")
    : '<div class="muted">No hay playlists todavía.</div>';
}

document.querySelector("#songForm").addEventListener("submit", async e => {
  e.preventDefault();
  const form = new FormData(e.target);
  const body = Object.fromEntries(form.entries());
  if (!body.artista_id) body.artista_id = null;
  else body.artista_id = Number(body.artista_id);

  try {
    await api("/api/canciones", { method:"POST", body:JSON.stringify(body) });
    document.querySelector("#message").textContent = "Canción guardada correctamente.";
    e.target.reset();
    cargarCanciones();
  } catch (err) {
    document.querySelector("#message").textContent = err.message;
  }
});

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
  }[c]));
}

checkHealth();
cargarCanciones();
cargarArtistas();
cargarPlaylists();
